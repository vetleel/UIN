import "./styles.css";

// Oppgave 1
let div = document.getElementById("remove");
let removeText = document.getElementById("remove-btn");
removeText.addEventListener(`click`, () => {
  div.remove();
});

// Oppgave 2
let changeText = document.getElementById("change-btn");
changeText.addEventListener(`click`, () => {
  document.getElementById("change").innerHTML = "ny";
});

// Oppgave 3
let input = document.querySelector("input");
let orginText = document.getElementById("input-text");

input.addEventListener("change", updateValue);

function updateValue(e) {
  orginText.textContent = e.target.value;
}

// Oppgave 4
let btn = document.getElementById("write-list");
const myList = ["item one", "item two", "item three"];
for (let i = 0; i < myList.length; i++) {
  if (
    btn.addEventListener(`click`, () => {
      document.getElementById("listOut").innerHTML = myList;
    })
  );
  else {
    break;
  }
}

// Oppgave 5
let dataType = document.getElementById("select");
let placeText = document.getElementById("text");
let btnbtn = document.getElementById("create");

btnbtn.addEventListener(`click`, upddateType);

function upddateType() {
  const newElement = document.createElement(dataType.value);
  newElement.innerHTML = dataType.value + " " + placeText.value;
  document.getElementById("placeholder").append(newElement);
}

// Oppgave 6
let removeLast = document.getElementById("remove-li");

removeLast.addEventListener(`click`, updateList);

function updateList() {
  let theList = document.getElementById("list");
  theList.removeChild(theList.childNodes[0]);
}

// Oppgave 7
let buttonOpp = document.getElementById("order");
buttonOpp.addEventListener(`click`, redBorder);

function redBorder() {
  let text = document.getElementById("name").value;
  let length = text.length;
  document.getElementById("theout").innerHTML = length;

  if (length < 4) {
    document.getElementById("order").style.border = "thick solid red";
  } else {
    document.getElementById("order").style.border = "thick solid blue";
  }
}

// Oppgave 8
let buttonNed = document.getElementById("color");
buttonNed.addEventListener(`click`, borderOn);

function borderOn() {
  const collection = document.getElementsByClassName("dd44");
  for (let i = 0; i < collection.length; i++) {
    if (i % 2) {
      collection[i].style.border = "thick solid pink";
    } else {
      collection[i].style.border = "thick solid green";
    }
  }
}
