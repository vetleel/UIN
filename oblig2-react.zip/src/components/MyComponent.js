import Title from "./Title";

const MyComponent = () => {
  return <Title title={"It works!"} />;
};

export default MyComponent;
