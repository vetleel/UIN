import Wrapper from "./Wrapper";

const Title = ({ title }) => {
  return (
    <>
      <h1>{title}</h1>
    </>
  );
};

export default Title;
