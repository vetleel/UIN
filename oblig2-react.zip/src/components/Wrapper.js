const Wrapper = ({ props }) => {
  return (
    <>
      <section className="flex">{props}</section>
    </>
  );
};

export default Wrapper;
