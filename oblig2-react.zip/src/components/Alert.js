export default function Alert({ setValue, showText, value }) {
  function handleChange_2(e) {
    setValue(e.target.value);
  }

  return (
    <>
      <br />
      <input type="text" value={value} onChange={handleChange_2} />
      <button type="button" onClick={showText}>
        Vis innhold/input
      </button>
    </>
  );
}
