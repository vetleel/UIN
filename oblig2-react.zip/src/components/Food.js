const foods = ["pizza", "hamburger", "coke"];

export default function Food() {
  return (
    <ul>
      {foods.map((fooding) => (
        <li>{fooding}</li>
      ))}
    </ul>
  );
}
