import MyComponent from "./components/MyComponent";
import Wrapper from "./components/Wrapper";
import "./styles.css";
import Food from "./components/Food";
import { useState } from "react";
import Alert from "./components/Alert";

export default function App() {
  const clickButton = () => {
    console.log("Clicked");
  };
  function handleChange(event) {
    console.log("Changed", event.target.value);
  }

  const [value, setValue] = useState("");
  const [text, setText] = useState("");
  const [show, setShow] = useState(false);

  const showText = () => {
    if (show === true) {
      setShow(false);
      setText(value);
    } else {
      setShow(true);
      setText(value);
    }
  };

  return (
    <div className="App">
      <h1>My First Component</h1>
      <MyComponent />
      <Wrapper props={"Children"} />
      <button onClick={clickButton}>Clicked</button>
      <input type="text" placeholder="to console" onChange={handleChange} />
      <br />
      <Food />
      <Alert value={value} setValue={setValue} showText={showText} />
      <p>Input Value: {value}</p>
      {show ? <p>Innhold/input: {text}</p> : null}
      <br />
    </div>
  );
}
