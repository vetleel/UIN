import { useEffect, useState } from 'react'
import { getActors } from '../lib/services/movieService'

export default function Actors() {
	const [actors, setActors] = useState()

	const getActorList = async () => {
		const actorList = await getActors()
		setActors(actorList);

	}
	useEffect(() => {
		getActorList()
	}, []);

	return (
		<>
			{actors?.map((actor) => (
				<article key={actor._id}>
					<h2>{actor.name}</h2>
				</article>
			))}
		</>
	)
}