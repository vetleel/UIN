import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import { getActors, getMovies } from "../lib/services/movieService";

export default function SpecificMovies() {

  const [data, setData] = useState()
  const [movieData, setMovieData] = useState()
  const [fultNavn, setFultNavn] = useState()

  const { slug } = useParams()
  const getActorNameData = async () => {
    const data = await getActors(slug)
    setData(data)
    data?.map((actors) => {
      setFultNavn(actors.Fullname);
      console.log(data)
    })
  }

  const getMovieData = async () => {
    const MovieDetails = await getMovies(fultNavn)
    setMovieData(MovieDetails)
  }

  useEffect(() => {
    getActorNameData();
    getMovieData();
  },[slug, fultNavn])

  console.log(movieData)


  return (
    <>
      {data?.map((actor) => (
        <article key={actor._id}>
          <h1>Navn: {actor.name}</h1>
          <h2>Kallenavn: {actor.slug}</h2>
          {movieData?.filter((movie) => movie.actor === actor.name).map((movie) => (
            <h3>Film: {movie?.title}</h3>
            ))}
            
        </article>
      ))}
    </>
  )
}