import { useEffect, useState } from 'react'
import { getMovies } from '../lib/services/movieService'

export default function Movies() {
	const [movies, setMovies] = useState()

	const getMovieList = async () => {
		const movieList = await getMovies()
		setMovies(movieList);
	}

	useEffect(() => {
		getMovieList()
	}, []);

	return (
		<>
			{movies?.map((movie) => (
				<article key={movie._id}>
					<h2>{movie.title}</h2>
				</article>
			))}
		</>
	)
}