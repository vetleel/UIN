import ActorName from '../components/ActorName'

export default function Actorname() {
    
    return (
       <ActorName />
    )
}