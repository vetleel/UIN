import SpecificMovies from '../components/SpecificMovies'

export default function MoviesReact() {
    
    return (
       <SpecificMovies />
    )
}