import Movies from '../components/Movies'

export default function MoviesReact() {
    
    return (
       <Movies />
    )
}