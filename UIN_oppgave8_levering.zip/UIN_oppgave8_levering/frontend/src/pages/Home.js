export default function Home() {
    return <h1>Forsiden til applikasjonen</h1>
}