import { Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Navigation from './Navigation'
import MoviesPage from './pages/MoviesPage'
import ActorsPage from './pages/ActorsPage'

import Actorname from './pages/Actorname'
import SpecificMovies from './components/SpecificMovies'


function App() {

	return (
		<>
			<Navigation />
			<Routes>
				<Route path="/" element={<Home />} />
				<Route path="movies" element={<MoviesPage />} />
				<Route path="actors" element={<ActorsPage />}/> 
				<Route path="actors/:name" element={<Actorname />} /> 
				<Route path="specificmovies" element={<SpecificMovies />} />
			</Routes>
		</>
	)
}
export default App