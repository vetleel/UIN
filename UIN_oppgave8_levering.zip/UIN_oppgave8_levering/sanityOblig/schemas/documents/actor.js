const actor = {
	name: 'actor',
	title: 'Actor',
	type: 'document',
	fields: [
		{
			name: 'name',
			title: 'Fullname',
			type: 'string',
			description: '',
			validation: (Rule) => Rule.required(),
		},
		{
			title: "Name",
			name: "slug",
			type: "slug",
			validation: (Rule) => Rule.required(),
		}
	]
}

export default actor;